package simpleStrategies;
public abstract class Evaluter {
	

	abstract public int evalute(int[][] originalBoard,int myNum,int eneNum,int movableCount);
}